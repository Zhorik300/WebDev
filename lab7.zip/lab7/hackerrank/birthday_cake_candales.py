N = int(input())
V = list(map(int, input().split()))
print(V.count(max(V)))
